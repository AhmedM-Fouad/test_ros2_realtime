// imu_publisher_rt.cpp
// Real-time friendly IMU publisher for ROS2 (preempt_rt)
#include <chrono>
#include <memory>
#include <string>
#include <array>
#include <atomic>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <stdexcept>
#include <cmath>
#include <cstdio>
#include <cstdlib>

#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/imu.hpp>

#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <pthread.h>
#include <sched.h>
#include <errno.h>
#include <time.h>

using namespace std::chrono_literals;

static constexpr size_t RX_BUF_SIZE = 4096; // must be power-of-two for simple mask if you change scheme
static constexpr int POLL_PERIOD_MS = 5;  // 4ms period

class IMUPublisher : public rclcpp::Node
{
public:
  IMUPublisher(const std::string & serial_port = "/dev/ttyACM0", speed_t baud = B921600)
  : Node("imu_publisher_rt"),
    serial_port_(serial_port),
    baud_rate_(baud),
    fd_(-1),
    rx_head_(0),
    rx_tail_(0),
    rt_thread_created_(false),
    stop_rt_thread_(false)
  {
    // Pre-allocate/prefill ring buffer (it's std::array so allocated statically)
    rx_buf_.fill(0);

    // Open serial port non-blocking
    fd_ = open(serial_port_.c_str(), O_RDWR | O_NOCTTY | O_SYNC | O_NONBLOCK);
    if (fd_ < 0) {
      RCLCPP_FATAL(this->get_logger(), "Failed to open serial port %s errno=%d", serial_port_.c_str(), errno);
      throw std::runtime_error("Serial port open failed");
    }

    configure_serial();

    // Create publisher (sensor_msgs::msg::Imu)
    imu_pub_ = this->create_publisher<sensor_msgs::msg::Imu>(
      "/imu/data_raw", rclcpp::QoS(100).best_effort()
    );

    // Create RT thread
    create_rt_thread();

    RCLCPP_INFO(this->get_logger(), "IMU Publisher RT node started on %s (baud macro %d)",
                serial_port_.c_str(), static_cast<int>(baud_rate_));
  }

  ~IMUPublisher()
  {
    // stop rt thread
    stop_rt_thread_.store(true, std::memory_order_release);

    if (rt_thread_created_) {
      // join; thread checks stop flag on next iteration
      pthread_join(rt_thread_, nullptr);
    }

    if (fd_ >= 0) {
      close(fd_);
      fd_ = -1;
    }
  }

  // Touch stack and heap to prefault (call once in main before creating threads)
  static void prefault_stack_and_heap()
  {
    // prefault some heap pages to avoid page faults later instead of HUGE stack-allocation.
    constexpr size_t PREFETCH_BYTES = 256 * 1024; // 256 KB
    char *buf = static_cast<char*>(malloc(PREFETCH_BYTES));
    if (buf) {
      memset(buf, 0, PREFETCH_BYTES);
      free(buf);
    }

    // also lock memory region
    if (mlockall(MCL_CURRENT | MCL_FUTURE) != 0) {
      perror("mlockall failed");
      std::cerr << "Warning: mlockall failed, realtime guarantees reduced\n";
    }
  }

private:
  // ---------- Serial configuration ----------
  void configure_serial()
  {
    struct termios tty;
    if (tcgetattr(fd_, &tty) != 0) {
      close(fd_);
      throw std::runtime_error("Failed to get serial attributes");
    }

    if (cfsetospeed(&tty, baud_rate_) != 0 || cfsetispeed(&tty, baud_rate_) != 0) {
      close(fd_);
      throw std::runtime_error("Failed to set serial speed");
    }

    // Raw mode: 8N1
    tty.c_cflag &= ~PARENB;
    tty.c_cflag &= ~CSTOPB;
    tty.c_cflag &= ~CSIZE;
    tty.c_cflag |= CS8;
    tty.c_cflag |= (CLOCAL | CREAD);
    tty.c_cflag &= ~CRTSCTS;

    tty.c_iflag &= ~(IXON | IXOFF | IXANY);
    tty.c_iflag &= ~IGNBRK;

    tty.c_lflag = 0;
    tty.c_oflag = 0;

    // In non-blocking mode VMIN/VTIME are ignored by read(2) because of O_NONBLOCK,
    // but set them to zero to be explicit.
    tty.c_cc[VMIN]  = 14;
    tty.c_cc[VTIME] = 1;

    if (tcsetattr(fd_, TCSANOW | TCSAFLUSH, &tty) != 0) {
      close(fd_);
      throw std::runtime_error("Failed to set serial attributes");
    }

    tcflush(fd_, TCIOFLUSH);
  }

  // ---------- Ring buffer (single producer (serial read inside RT thread) and single consumer (parser in same RT thread)) ----------
  inline size_t rx_capacity() const { return RX_BUF_SIZE; }
  inline size_t rx_size() const {
    size_t h = rx_head_.load(std::memory_order_acquire);
    size_t t = rx_tail_.load(std::memory_order_acquire);
    return (h >= t) ? (h - t) : (RX_BUF_SIZE + h - t);
  }

  // Write bytes (called by RT thread directly after read)
  void rx_push_bytes(const uint8_t *data, size_t len) {
    // very simple non-blocking push; if buffer overflow would occur, drop oldest bytes
    size_t head = rx_head_.load(std::memory_order_relaxed);
    size_t tail = rx_tail_.load(std::memory_order_relaxed);
    for (size_t i = 0; i < len; ++i) {
      rx_buf_[head] = data[i];
      head = (head + 1) % RX_BUF_SIZE;
      if (head == tail) {
        // buffer full, advance tail to drop oldest byte
        tail = (tail + 1) % RX_BUF_SIZE;
      }
    }
    // store back atomically (store tail before head to keep consumer valid)
    rx_tail_.store(tail, std::memory_order_release);
    rx_head_.store(head, std::memory_order_release);
  }

  // Peek byte at offset (0 == oldest)
  bool rx_peek(size_t offset, uint8_t & out) {
    size_t sz = rx_size();
    if (offset >= sz) return false;
    size_t t = rx_tail_.load(std::memory_order_acquire);
    size_t idx = (t + offset) % RX_BUF_SIZE;
    out = rx_buf_[idx];
    return true;
  }

  // Consume n bytes from tail
  void rx_consume(size_t n) {
    size_t sz = rx_size();
    if (n >= sz) {
      // consume all: set tail = head
      rx_tail_.store(rx_head_.load(std::memory_order_relaxed),
                    std::memory_order_release);
    } else {
      size_t cur_tail = rx_tail_.load(std::memory_order_relaxed);
      size_t new_tail = (cur_tail + n) % RX_BUF_SIZE;
      rx_tail_.store(new_tail, std::memory_order_release);
    }
  }


  // ---------- Packet parsing & publishing ----------
  void parse_and_publish_available()
  {
    // Packet format assumed: 2-byte header 0xAA 0x55, followed by 12 bytes payload = 14 total
    constexpr size_t PACKET_TOTAL = 14;
    while (rx_size() >= PACKET_TOTAL) {
      uint8_t b0=0, b1=0;
      if (!rx_peek(0, b0) || !rx_peek(1, b1)) break;
      if (b0 == 0xAA && b1 == 0x55) {
        // read payload into local buffer (no allocations)
        uint8_t payload[12];
        bool ok = true;
        for (size_t i = 0; i < 12; ++i) {
          if (!rx_peek(2 + i, payload[i])) { ok = false; break; }
        }
        if (!ok) break;
        // consume the full packet
        rx_consume(PACKET_TOTAL);
        // publish payload (RT safe)
        publish_packet(payload);
      } else {
        // drop one byte
        rx_consume(1);
      }
    }
  }

  void publish_packet(const uint8_t *payload12)
  {
    auto unpack16 = [](const uint8_t *p) -> int16_t {
      uint16_t v = (static_cast<uint16_t>(p[0]) << 8) | static_cast<uint16_t>(p[1]);
      return static_cast<int16_t>(v);
    };

    int16_t ax = unpack16(&payload12[0]);
    int16_t ay = unpack16(&payload12[2]);
    int16_t az = unpack16(&payload12[4]);
    int16_t gx = unpack16(&payload12[6]);
    int16_t gy = unpack16(&payload12[8]);
    int16_t gz = unpack16(&payload12[10]);

    constexpr double g          = 9.81;
    constexpr double accel_scale = g / 16384.0;   // example: raw / 16384 -> g's, then *9.81
    constexpr double deg2rad     = M_PI / 180.0;
    constexpr double gyro_scale  = deg2rad / 131.0; // example scale if 131 LSB/(deg/s)

    sensor_msgs::msg::Imu imu_msg;
    imu_msg.header.stamp = this->now();
    imu_msg.header.frame_id = "imu_link";

    imu_msg.linear_acceleration.x = static_cast<double>(ax) * accel_scale;
    imu_msg.linear_acceleration.y = static_cast<double>(ay) * accel_scale;
    imu_msg.linear_acceleration.z = static_cast<double>(az) * accel_scale;

    imu_msg.angular_velocity.x = static_cast<double>(gx) * gyro_scale;
    imu_msg.angular_velocity.y = static_cast<double>(gy) * gyro_scale;
    imu_msg.angular_velocity.z = static_cast<double>(gz) * gyro_scale;

    // Optionally fill covariances (unknown here -> set to -1)
    imu_msg.orientation_covariance[0] = -1;
    imu_msg.angular_velocity_covariance[0] = -1;
    imu_msg.linear_acceleration_covariance[0] = -1;

    // Publish normally. Keep publish path simple and robust for RT thread.
    // Note: rclcpp publishers are thread-safe for publish().
    try {
      imu_pub_->publish(imu_msg);
    } catch (const std::exception & e) {
      RCLCPP_WARN(this->get_logger(), "Publish exception: %s", e.what());
    } catch (...) {
      RCLCPP_WARN(this->get_logger(), "Unknown publish exception");
    }
  }


  // ---------- RT thread: poll loop ----------
  static void * rt_thread_trampoline(void * arg) {
    IMUPublisher * self = static_cast<IMUPublisher*>(arg);
    self->rt_poll_loop();
    return nullptr;
  }

  void create_rt_thread()
  {
    pthread_attr_t attr;
    pthread_attr_init(&attr);

    // set scheduling policy and priority
    if (pthread_attr_setschedpolicy(&attr, SCHED_FIFO) != 0) {
      RCLCPP_WARN(this->get_logger(), "Unable to set sched policy on pthread_attr");
    }
    struct sched_param param;
    param.sched_priority = 98; // choose 1..99, leave headroom from 99
    if (pthread_attr_setschedparam(&attr, &param) != 0) {
      RCLCPP_WARN(this->get_logger(), "Unable to set sched param on pthread_attr");
    }
    pthread_attr_setinheritsched(&attr, PTHREAD_EXPLICIT_SCHED);

    int err = pthread_create(&rt_thread_, &attr, &IMUPublisher::rt_thread_trampoline, this);
    if (err != 0) {
      RCLCPP_FATAL(this->get_logger(), "Failed to create RT thread: %s", std::strerror(err));
      pthread_attr_destroy(&attr);
      throw std::runtime_error("Failed to create RT thread");
    }
    rt_thread_created_ = true;

    pthread_attr_destroy(&attr);

    // Optionally set CPU affinity to a dedicated core (uncomment and adjust core number)
    cpu_set_t cpus;
    CPU_ZERO(&cpus);
    CPU_SET(1, &cpus); // pin to core 1
    int sret = pthread_setaffinity_np(rt_thread_, sizeof(cpu_set_t), &cpus);
    if (sret != 0) {
      RCLCPP_WARN(this->get_logger(), "Failed to set thread affinity: %s", std::strerror(sret));
    }
  }

  void rt_poll_loop()
  {
    // Use CLOCK_MONOTONIC with absolute sleeps to avoid drift
    struct timespec next;
    clock_gettime(CLOCK_MONOTONIC, &next);

    const long period_ns = POLL_PERIOD_MS * 1000000L;

    uint8_t tmpbuf[512];

    while (!stop_rt_thread_.load(std::memory_order_acquire) && rclcpp::ok()) {
      // read available bytes from serial in a deterministic manner
      int bytes_avail = 0;
      if (fd_ >= 0 && ioctl(fd_, FIONREAD, &bytes_avail) == 0 && bytes_avail > 0) {
        // cap read to tmpbuf
        int to_read = bytes_avail;
        if (to_read > static_cast<int>(sizeof(tmpbuf))) to_read = static_cast<int>(sizeof(tmpbuf));
        ssize_t n = ::read(fd_, tmpbuf, static_cast<size_t>(to_read));
        if (n > 0) {
          rx_push_bytes(tmpbuf, static_cast<size_t>(n));
        }
        // else n == -1: if EAGAIN nothing; else ignore errors for now
      }

      // parse as many complete packets as possible (in RT thread)
      parse_and_publish_available();

      // wait until next period (absolute)
      next.tv_nsec += period_ns;
      while (next.tv_nsec >= 1000000000L) {
        next.tv_nsec -= 1000000000L;
        next.tv_sec += 1;
      }
      // nanosleep with TIMER_ABSTIME for deterministic wake
      clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &next, nullptr);
    }
  }

  // ---------- Members ----------
  std::string serial_port_;
  speed_t baud_rate_;
  int fd_;

  std::array<uint8_t, RX_BUF_SIZE> rx_buf_;
  std::atomic<size_t> rx_head_;
  std::atomic<size_t> rx_tail_;

  rclcpp::Publisher<sensor_msgs::msg::Imu>::SharedPtr imu_pub_;

  // RT thread
  pthread_t rt_thread_;
  bool rt_thread_created_;
  std::atomic<bool> stop_rt_thread_;

}; // class IMUPublisher

int main(int argc, char * argv[])
{
  // Prefault stack and lock memory before starting ROS init / threads
  IMUPublisher::prefault_stack_and_heap();

  rclcpp::init(argc, argv);

  // Optionally pass serial port via argv
  std::string port = "/dev/ttyACM0";
  if (argc > 1) port = argv[1];

  try {
    auto node = std::make_shared<IMUPublisher>(port, B921600);
    // We don't spin with executor here; the RT thread does reads+publishing.
    // However, some ROS infrastructure may need spinning for subscription callbacks, etc.
    // We'll spin the node in the main thread to allow ROS callbacks (non-RT).
    rclcpp::spin(node);
    rclcpp::shutdown();
  } catch (const std::exception & ex) {
    std::cerr << "Fatal error: " << ex.what() << std::endl;
    return 2;
  }

  return 0;
}
