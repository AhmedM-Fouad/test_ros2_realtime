// imu_publisher_rt.cpp
// Real-time friendly IMU publisher for ROS2 (preempt_rt)
#include <chrono>
#include <memory>
#include <string>
#include <array>
#include <atomic>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <stdexcept>

#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/imu.hpp>

#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <pthread.h>
#include <sched.h>
#include <errno.h>

using namespace std::chrono_literals;

static constexpr size_t RX_BUF_SIZE = 4096; // must be power-of-two for simple mask if you change scheme
static constexpr int POLL_PERIOD_MS = 4;    // 4ms period

class IMUPublisher : public rclcpp::Node
{
public:
  IMUPublisher(const std::string & serial_port = "/dev/ttyACM0", speed_t baud = B921600)
  : Node("imu_publisher_rt"),
    serial_port_(serial_port),
    baud_rate_(baud),
    fd_(-1),
    rx_head_(0),
    rx_tail_(0),
    stop_rt_thread_(false)
  {
    // Pre-allocate/prefill ring buffer (it's std::array so allocated statically)
    rx_buf_.fill(0);

    // Open serial port non-blocking
    fd_ = open(serial_port_.c_str(), O_RDWR | O_NOCTTY | O_SYNC | O_NONBLOCK);
    if (fd_ < 0) {
      RCLCPP_FATAL(this->get_logger(), "Failed to open serial port %s errno=%d", serial_port_.c_str(), errno);
      throw std::runtime_error("Serial port open failed");
    }

    configure_serial();

    // Preallocate imu message
    imu_msg_.header.frame_id = "imu_link";
    imu_msg_.linear_acceleration_covariance[0] = -1.0;
    imu_msg_.angular_velocity_covariance[0] = -1.0;

    // Create publisher (QoS kept default; consider a suitable RT QoS profile)
    imu_pub_ = this->create_publisher<sensor_msgs::msg::Imu>("/imu/data_raw", rclcpp::SensorDataQoS());

    // Create RT thread
    create_rt_thread();

    RCLCPP_INFO(this->get_logger(), "IMU Publisher RT node started on %s at baud %d", serial_port_.c_str(), 921600);
  }

  ~IMUPublisher()
  {
    // stop rt thread
    stop_rt_thread_.store(true);
    if (rt_thread_created_) {
      pthread_join(rt_thread_, nullptr);
    }

    if (fd_ >= 0) {
      close(fd_);
      fd_ = -1;
    }
  }

  // Touch stack and heap to prefault (call once in main before creating threads)
  static void prefault_stack_and_heap()
  {
    // prefault some stack memory to avoid page faults later
    constexpr size_t MAX_SAFE_STACK = 1024 * 256; // 256 KB
    volatile unsigned char dummy[MAX_SAFE_STACK];
    memset((void*)dummy, 0, sizeof(dummy));
    // also lock memory region
    if (mlockall(MCL_CURRENT | MCL_FUTURE) != 0) {
      perror("mlockall failed");
      // Not fatal here but warn
      std::cerr << "Warning: mlockall failed, realtime guarantees reduced\n";
    }
  }

private:
  // ---------- Serial configuration ----------
  void configure_serial()
  {
    struct termios tty;
    if (tcgetattr(fd_, &tty) != 0) {
      throw std::runtime_error("Failed to get serial attributes");
    }

    cfsetospeed(&tty, baud_rate_);
    cfsetispeed(&tty, baud_rate_);

    // Raw mode: 8N1
    tty.c_cflag &= ~PARENB;
    tty.c_cflag &= ~CSTOPB;
    tty.c_cflag &= ~CSIZE;
    tty.c_cflag |= CS8;
    tty.c_cflag |= (CLOCAL | CREAD);
    tty.c_cflag &= ~CRTSCTS;

    tty.c_iflag &= ~(IXON | IXOFF | IXANY);
    tty.c_iflag &= ~IGNBRK;

    tty.c_lflag = 0;
    tty.c_oflag = 0;

    // Non-blocking read
    tty.c_cc[VMIN]  = 0;
    tty.c_cc[VTIME] = 0;

    if (tcsetattr(fd_, TCSANOW | TCSAFLUSH, &tty) != 0) {
      throw std::runtime_error("Failed to set serial attributes");
    }

    tcflush(fd_, TCIOFLUSH);
  }

  // ---------- Ring buffer (single producer (serial read inside RT thread) and single consumer (parser in same RT thread)) ----------
  inline size_t rx_capacity() const { return RX_BUF_SIZE; }
  inline size_t rx_size() const {
    size_t h = rx_head_.load(std::memory_order_acquire);
    size_t t = rx_tail_.load(std::memory_order_acquire);
    return (h >= t) ? (h - t) : (RX_BUF_SIZE + h - t);
  }
  // Write bytes (called by RT thread directly after read)
  void rx_push_bytes(const uint8_t *data, size_t len) {
    // very simple non-blocking push; if buffer overflow would occur, drop oldest bytes
    for (size_t i = 0; i < len; ++i) {
      rx_buf_[rx_head_] = data[i];
      rx_head_ = (rx_head_ + 1) % RX_BUF_SIZE;
      if (rx_head_ == rx_tail_) {
        // buffer full, advance tail to drop oldest byte
        rx_tail_ = (rx_tail_ + 1) % RX_BUF_SIZE;
      }
    }
  }
  // Peek byte at offset (0 == oldest)
  bool rx_peek(size_t offset, uint8_t & out) {
    if (offset >= rx_size()) return false;
    size_t idx = (rx_tail_ + offset) % RX_BUF_SIZE;
    out = rx_buf_[idx];
    return true;
  }
  // Consume n bytes from tail
  void rx_consume(size_t n) {
    size_t sz = rx_size();
    if (n >= sz) {
      rx_tail_ = rx_head_; // consume all
    } else {
      rx_tail_ = (rx_tail_ + n) % RX_BUF_SIZE;
    }
  }

  // ---------- Packet parsing & publishing ----------
  void parse_and_publish_available()
  {
    // Packet format assumed: 2-byte header 0xAA 0x55, followed by 12 bytes payload = 14 total
    constexpr size_t PACKET_TOTAL = 14;
    while (rx_size() >= PACKET_TOTAL) {
      uint8_t b0=0, b1=0;
      if (!rx_peek(0, b0) || !rx_peek(1, b1)) break;
      if (b0 == 0xAA && b1 == 0x55) {
        // read payload into local buffer (no allocations)
        uint8_t payload[12];
        for (size_t i = 0; i < 12; ++i) {
          rx_peek(2 + i, payload[i]);
        }
        // consume the full packet
        rx_consume(PACKET_TOTAL);
        // publish payload (RT safe)
        publish_packet(payload);
      } else {
        // drop one byte
        rx_consume(1);
      }
    }
  }

  void publish_packet(const uint8_t *payload12)
  {
    auto unpack16 = [](const uint8_t *p) -> int16_t {
      return static_cast<int16_t>((static_cast<int16_t>(p[0]) << 8) | static_cast<int16_t>(p[1]));
    };

    int16_t ax = unpack16(&payload12[0]);
    int16_t ay = unpack16(&payload12[2]);
    int16_t az = unpack16(&payload12[4]);
    int16_t gx = unpack16(&payload12[6]);
    int16_t gy = unpack16(&payload12[8]);
    int16_t gz = unpack16(&payload12[10]);

    constexpr double g          = 9.81;
    constexpr double accel_scale = g / 16384.0;
    constexpr double deg2rad     = M_PI / 180.0;
    constexpr double gyro_scale  = deg2rad / 131.0;

    // Update preallocated message
    imu_msg_.header.stamp = this->now();
    imu_msg_.linear_acceleration.x = static_cast<double>(ax) * accel_scale;
    imu_msg_.linear_acceleration.y = static_cast<double>(ay) * accel_scale;
    imu_msg_.linear_acceleration.z = static_cast<double>(az) * accel_scale;

    imu_msg_.angular_velocity.x = static_cast<double>(gx) * gyro_scale;
    imu_msg_.angular_velocity.y = static_cast<double>(gy) * gyro_scale;
    imu_msg_.angular_velocity.z = static_cast<double>(gz) * gyro_scale;

    // Try to use loaned message if backend supports it to avoid allocations
    // NOTE: This API requires an rclcpp version that supports loaned messages.
    // We guard with try/catch in case it's not supported by RMW/ROS2 version.
    try {
      auto maybe_loaned = imu_pub_->borrow_loaned_message();
      if (maybe_loaned) {
        // copy into loaned message (no allocation)
        *maybe_loaned = imu_msg_;
        imu_pub_->publish(std::move(maybe_loaned));
        return;
      }
    } catch (...) {
      // if loaned not available, fall back to normal publish below
    }

    // Fallback: publish normal preallocated message (should still be mostly allocation-free)
    imu_pub_->publish(imu_msg_);
  }

  // ---------- RT thread: poll loop ----------
  static void * rt_thread_trampoline(void * arg) {
    IMUPublisher * self = static_cast<IMUPublisher*>(arg);
    self->rt_poll_loop();
    return nullptr;
  }

  void create_rt_thread()
  {
    pthread_attr_t attr;
    pthread_attr_init(&attr);

    // set scheduling policy and priority
    pthread_attr_setschedpolicy(&attr, SCHED_FIFO);
    struct sched_param param;
    param.sched_priority = 80; // choose 1..99, leave headroom from 99
    pthread_attr_setschedparam(&attr, &param);
    pthread_attr_setinheritsched(&attr, PTHREAD_EXPLICIT_SCHED);

    // Optionally set stack size (increase if needed)
    // pthread_attr_setstacksize(&attr, 512*1024);

    int err = pthread_create(&rt_thread_, &attr, &IMUPublisher::rt_thread_trampoline, this);
    if (err != 0) {
      RCLCPP_FATAL(this->get_logger(), "Failed to create RT thread: %s", std::strerror(err));
      throw std::runtime_error("Failed to create RT thread");
    }
    rt_thread_created_ = true;

    pthread_attr_destroy(&attr);

    // Optionally set CPU affinity to a dedicated core (uncomment and adjust core number)
    // cpu_set_t cpus;
    // CPU_ZERO(&cpus);
    // CPU_SET(1, &cpus); // pin to core 1
    // pthread_setaffinity_np(rt_thread_, sizeof(cpu_set_t), &cpus);
  }

  void rt_poll_loop()
  {
    // Use CLOCK_MONOTONIC with absolute sleeps to avoid drift
    struct timespec next;
    clock_gettime(CLOCK_MONOTONIC, &next);

    const long period_ns = POLL_PERIOD_MS * 1000000L;

    uint8_t tmpbuf[512];

    while (!stop_rt_thread_.load(std::memory_order_acquire) && rclcpp::ok()) {
      // read available bytes from serial in a deterministic manner
      int bytes_avail = 0;
      if (ioctl(fd_, FIONREAD, &bytes_avail) == 0 && bytes_avail > 0) {
        // cap read to tmpbuf
        int to_read = bytes_avail;
        if (to_read > static_cast<int>(sizeof(tmpbuf))) to_read = sizeof(tmpbuf);
        ssize_t n = ::read(fd_, tmpbuf, to_read);
        if (n > 0) {
          rx_push_bytes(tmpbuf, static_cast<size_t>(n));
        }
        // else n == -1: if EAGAIN nothing; else ignore errors for now
      }

      // parse as many complete packets as possible (in RT thread)
      parse_and_publish_available();

      // wait until next period (absolute)
      next.tv_nsec += period_ns;
      while (next.tv_nsec >= 1000000000L) {
        next.tv_nsec -= 1000000000L;
        next.tv_sec += 1;
      }
      // nanosleep with TIMER_ABSTIME for deterministic wake
      clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &next, nullptr);
    }
  }

  // ---------- Members ----------
  std::string serial_port_;
  speed_t baud_rate_;
  int fd_;

  std::array<uint8_t, RX_BUF_SIZE> rx_buf_;
  std::atomic<size_t> rx_head_;
  std::atomic<size_t> rx_tail_;

  rclcpp::Publisher<sensor_msgs::msg::Imu>::SharedPtr imu_pub_;
  sensor_msgs::msg::Imu imu_msg_; // preallocated

  // RT thread
  pthread_t rt_thread_;
  bool rt_thread_created_ = false;
  std::atomic<bool> stop_rt_thread_;

}; // class IMUPublisher

int main(int argc, char * argv[])
{
  // Prefault stack and lock memory before starting ROS init / threads
  IMUPublisher::prefault_stack_and_heap();

  rclcpp::init(argc, argv);

  // Optionally pass serial port via argv
  std::string port = "/dev/ttyACM0";
  if (argc > 1) port = argv[1];

  try {
    auto node = std::make_shared<IMUPublisher>(port, B921600);
    // We don't spin with executor here; the RT thread does reads+publishing.
    // However, some ROS infrastructure may need spinning for subscription callbacks, etc.
    // We will spin the node in the main thread to allow ROS callbacks (non-RT).
    rclcpp::spin(node);
    rclcpp::shutdown();
  } catch (const std::exception & ex) {
    std::cerr << "Fatal error: " << ex.what() << std::endl;
    return 2;
  }

  return 0;
}


// #include <chrono>
// #include <memory>
// #include <string>
// #include <iostream>
// #include <vector>
// #include <cmath>
// #include <stdexcept>

// #include <rclcpp/rclcpp.hpp>
// #include <sensor_msgs/msg/imu.hpp>

// #include <fcntl.h>
// #include <unistd.h>
// #include <termios.h>
// #include <sys/ioctl.h>

// using namespace std::chrono_literals;

// class IMUPublisher : public rclcpp::Node
// {
// public:
//     IMUPublisher()
//     : Node("imu_publisher")
//     {
//         // === Serial Port ===
//         serial_port_ = "/dev/ttyACM0";
//         baud_rate_   = B921600;

//         fd_ = open(serial_port_.c_str(), O_RDWR | O_NOCTTY | O_SYNC);
//         if (fd_ < 0) {
//             RCLCPP_FATAL(this->get_logger(), "Failed to open serial port %s", serial_port_.c_str());
//             throw std::runtime_error("Serial port open failed");
//         }

//         configure_serial();

//         // === Publisher ===
//         imu_pub_ = this->create_publisher<sensor_msgs::msg::Imu>("/imu/data_raw", 1000);

//         // === Timer: poll serial every 4 ms ===
//         timer_ = this->create_wall_timer(4ms, std::bind(&IMUPublisher::read_serial, this));

//         RCLCPP_INFO(this->get_logger(), "IMU Publisher started on %s at %d baud",
//                     serial_port_.c_str(), 921600);
//     }

//     ~IMUPublisher()
//     {
//         if (fd_ >= 0) {
//             close(fd_);
//         }
//     }

// private:
//     void configure_serial()
//     {
//         struct termios tty;
//         if (tcgetattr(fd_, &tty) != 0) {
//             throw std::runtime_error("Failed to get serial attributes");
//         }

//         cfsetospeed(&tty, baud_rate_);
//         cfsetispeed(&tty, baud_rate_);

//         // Raw mode: 8N1
//         tty.c_cflag &= ~PARENB;
//         tty.c_cflag &= ~CSTOPB;
//         tty.c_cflag &= ~CSIZE;
//         tty.c_cflag |= CS8;
//         tty.c_cflag |= (CLOCAL | CREAD);
//         tty.c_cflag &= ~CRTSCTS;

//         tty.c_iflag &= ~(IXON | IXOFF | IXANY);
//         tty.c_iflag &= ~IGNBRK;

//         tty.c_lflag = 0;
//         tty.c_oflag = 0;

//         // Non-blocking read
//         tty.c_cc[VMIN]  = 0;
//         tty.c_cc[VTIME] = 0;

//         if (tcsetattr(fd_, TCSANOW, &tty) != 0) {
//             throw std::runtime_error("Failed to set serial attributes");
//         }

//         tcflush(fd_, TCIOFLUSH);
//     }

//     void read_serial()
//     {
//         uint8_t buffer[64];
//         ssize_t n = read(fd_, buffer, sizeof(buffer));
//         if (n <= 0) return;

//         // Append to ring buffer
//         rx_buf_.insert(rx_buf_.end(), buffer, buffer + n);

//         // Parse as many complete packets as possible
//         while (rx_buf_.size() >= 14) { // 2 header + 12 payload
//             if (rx_buf_[0] == 0xAA && rx_buf_[1] == 0x55) {
//                 // Got header + enough data
//                 std::array<uint8_t, 12> payload;
//                 std::copy(rx_buf_.begin() + 2, rx_buf_.begin() + 14, payload.begin());
//                 rx_buf_.erase(rx_buf_.begin(), rx_buf_.begin() + 14);
//                 publish_packet(payload);
//             } else {
//                 // Drop until potential header
//                 rx_buf_.erase(rx_buf_.begin());
//             }
//         }
//     }

//     void publish_packet(const std::array<uint8_t, 12> &payload)
//     {
//         auto unpack16 = [](const uint8_t *p) -> int16_t {
//             return static_cast<int16_t>((p[0] << 8) | p[1]);
//         };

//         int16_t ax = unpack16(&payload[0]);
//         int16_t ay = unpack16(&payload[2]);
//         int16_t az = unpack16(&payload[4]);
//         int16_t gx = unpack16(&payload[6]);
//         int16_t gy = unpack16(&payload[8]);
//         int16_t gz = unpack16(&payload[10]);

//         constexpr double g          = 9.81;
//         constexpr double accel_scale = g / 16384.0;
//         constexpr double deg2rad     = M_PI / 180.0;
//         constexpr double gyro_scale  = deg2rad / 131.0;

//         auto imu_msg = sensor_msgs::msg::Imu();
//         imu_msg.header.stamp    = this->get_clock()->now();
//         imu_msg.header.frame_id = "imu_link";

//         imu_msg.linear_acceleration.x = ax * accel_scale;
//         imu_msg.linear_acceleration.y = ay * accel_scale;
//         imu_msg.linear_acceleration.z = az * accel_scale;

//         imu_msg.angular_velocity.x = gx * gyro_scale;
//         imu_msg.angular_velocity.y = gy * gyro_scale;
//         imu_msg.angular_velocity.z = gz * gyro_scale;

//         // Unknown covariances
//         imu_msg.linear_acceleration_covariance[0] = -1.0;
//         imu_msg.angular_velocity_covariance[0]    = -1.0;

//         imu_pub_->publish(imu_msg);
//     }

//     std::string serial_port_;
//     int fd_;
//     speed_t baud_rate_;

//     std::vector<uint8_t> rx_buf_; // circular buffer

//     rclcpp::Publisher<sensor_msgs::msg::Imu>::SharedPtr imu_pub_;
//     rclcpp::TimerBase::SharedPtr timer_;
// };

// int main(int argc, char * argv[])
// {
//     rclcpp::init(argc, argv);
//     auto node = std::make_shared<IMUPublisher>();
//     rclcpp::spin(node);
//     rclcpp::shutdown();
//     return 0;
// }
