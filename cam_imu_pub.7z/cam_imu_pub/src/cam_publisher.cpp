//#include <chrono>
//#include <memory>
//#include <string>
//#include <iostream>
//#include <vector>
//#include <cmath>
//#include <stdexcept>

//#include <rclcpp/rclcpp.hpp>
//#include <sensor_msgs/msg/imu.hpp>

//#include <fcntl.h>
//#include <unistd.h>
//#include <termios.h>
//#include <sys/ioctl.h>

//using namespace std::chrono_literals;

//class IMUPublisher : public rclcpp::Node
//{
//public:
    //IMUPublisher()
    //: Node("imu_publisher")
    //{
        //// === Serial Port ===
        //serial_port_ = "/dev/ttyACM0";
        //baud_rate_ = B921600;

        //fd_ = open(serial_port_.c_str(), O_RDWR | O_NOCTTY | O_SYNC);
        //if (fd_ < 0) {
            //RCLCPP_FATAL(this->get_logger(), "Failed to open serial port %s", serial_port_.c_str());
            //throw std::runtime_error("Serial port open failed");
        //}

        //configure_serial();

        //// === Publisher ===
        //imu_pub_ = this->create_publisher<sensor_msgs::msg::Imu>("/imu/data_raw", 1000);

        //// === Timer (250 Hz → 4 ms) ===
        //timer_ = this->create_wall_timer(1ms, std::bind(&IMUPublisher::publish_imu, this));

        //RCLCPP_INFO(this->get_logger(), "IMU Publisher started on %s at 460800 baud", serial_port_.c_str());
    //}

    //~IMUPublisher()
    //{
        //if (fd_ >= 0) {
            //close(fd_);
        //}
    //}

//private:
    ////void configure_serial()
    ////{
        ////struct termios tty;
        ////if (tcgetattr(fd_, &tty) != 0) {
            ////throw std::runtime_error("Failed to get serial attributes");
        ////}

        ////cfsetospeed(&tty, baud_rate_);
        ////cfsetispeed(&tty, baud_rate_);

        ////tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS8; // 8-bit chars
        ////tty.c_iflag &= ~IGNBRK;                     // disable break processing
        ////tty.c_lflag = 0;                            // no signaling chars, no echo, no canonical
        ////tty.c_oflag = 0;                            // no remapping, no delays
        ////tty.c_cc[VMIN] = 0;                         // non-blocking read
        ////tty.c_cc[VTIME] = 1;                        // 0.1s timeout

        ////tty.c_iflag &= ~(IXON | IXOFF | IXANY);     // shut off xon/xoff ctrl

        ////tty.c_cflag |= (CLOCAL | CREAD);            // ignore modem controls, enable reading
        ////tty.c_cflag &= ~(PARENB | PARODD);          // shut off parity
        ////tty.c_cflag &= ~CSTOPB;
        ////tty.c_cflag &= ~CRTSCTS;

        ////if (tcsetattr(fd_, TCSANOW, &tty) != 0) {
            ////throw std::runtime_error("Failed to set serial attributes");
        ////}
    ////}
    
    //void configure_serial()
    //{
        //struct termios tty;
        //if (tcgetattr(fd_, &tty) != 0) {
            //throw std::runtime_error("Failed to get serial attributes");
        //}

        //// Set baud rate (make sure baud_rate_ is a termios constant, e.g. B921600)
        //cfsetospeed(&tty, baud_rate_);
        //cfsetispeed(&tty, baud_rate_);

        //// Raw mode: 8N1, no flow control
        //tty.c_cflag &= ~PARENB;
        //tty.c_cflag &= ~CSTOPB;
        //tty.c_cflag &= ~CSIZE;
        //tty.c_cflag |= CS8;
        //tty.c_cflag |= (CLOCAL | CREAD);
        //tty.c_cflag &= ~CRTSCTS;

        //tty.c_iflag &= ~(IXON | IXOFF | IXANY); // no SW flow control
        //tty.c_iflag &= ~IGNBRK;

        //tty.c_lflag = 0;  // no local modes
        //tty.c_oflag = 0;  // no output processing

        //// Blocking read until a full packet is ready
        //tty.c_cc[VMIN] = 14;   // size of your packet (header + 6x int16)
        //tty.c_cc[VTIME] = 1;   // 0.1s timeout

        //// Apply attributes
        //if (tcsetattr(fd_, TCSANOW, &tty) != 0) {
            //throw std::runtime_error("Failed to set serial attributes");
        //}

        //// Flush away any garbage
        //tcflush(fd_, TCIOFLUSH);
    //}


    //void publish_imu()
    //{
        //uint8_t header[2];
        //uint8_t payload[12];

        //// Look for header 0xAA 0x55
        //while (true) {
            //ssize_t n = read(fd_, header, 1);
            //if (n <= 0) return;
            //if (header[0] == 0xAA) {
                //n = read(fd_, header + 1, 1);
                //if (n > 0 && header[1] == 0x55) {
                    //break;
                //}
            //}
        //}

        //// Read 12-byte payload
        //ssize_t n = read(fd_, payload, 12);
        //if (n != 12) {
            //RCLCPP_WARN(this->get_logger(), "Incomplete IMU packet");
            //return;
        //}

        //// Unpack big-endian signed 16-bit
        //auto unpack16 = [](uint8_t *p) -> int16_t {
            //return (int16_t)((p[0] << 8) | p[1]);
        //};

        //int16_t ax = unpack16(&payload[0]);
        //int16_t ay = unpack16(&payload[2]);
        //int16_t az = unpack16(&payload[4]);
        //int16_t gx = unpack16(&payload[6]);
        //int16_t gy = unpack16(&payload[8]);
        //int16_t gz = unpack16(&payload[10]);

        //// Convert to SI
        //constexpr double g = 9.81;
        //constexpr double accel_scale = g / 16384.0;
        //constexpr double deg2rad = M_PI / 180.0;
        //constexpr double gyro_scale = deg2rad / 131.0;

        //auto imu_msg = sensor_msgs::msg::Imu();
        //imu_msg.header.stamp = this->get_clock()->now();
        //imu_msg.header.frame_id = "imu_link";

        //imu_msg.linear_acceleration.x = ax * accel_scale;
        //imu_msg.linear_acceleration.y = ay * accel_scale;
        //imu_msg.linear_acceleration.z = az * accel_scale;

        //imu_msg.angular_velocity.x = gx * gyro_scale;
        //imu_msg.angular_velocity.y = gy * gyro_scale;
        //imu_msg.angular_velocity.z = gz * gyro_scale;

        //// Covariances set to -1.0 (unknown)
        //imu_msg.linear_acceleration_covariance[0] = -1.0;
        //imu_msg.angular_velocity_covariance[0] = -1.0;

        //imu_pub_->publish(imu_msg);
    //}

    //std::string serial_port_;
    //int fd_;
    //speed_t baud_rate_;
    //rclcpp::Publisher<sensor_msgs::msg::Imu>::SharedPtr imu_pub_;
    //rclcpp::TimerBase::SharedPtr timer_;
//};


//int main(int argc, char * argv[])
//{
    //rclcpp::init(argc, argv);
    //auto node = std::make_shared<IMUPublisher>();
    //rclcpp::spin(node);
    //rclcpp::shutdown();
    //return 0;
//}

#include <chrono>
#include <memory>
#include <string>
#include <iostream>
#include <vector>
#include <cmath>
#include <stdexcept>

#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/imu.hpp>

#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <sys/ioctl.h>

using namespace std::chrono_literals;

class IMUPublisher : public rclcpp::Node
{
public:
    IMUPublisher()
    : Node("imu_publisher")
    {
        // === Serial Port ===
        serial_port_ = "/dev/ttyACM0";
        baud_rate_ = B921600;

        fd_ = open(serial_port_.c_str(), O_RDWR | O_NOCTTY | O_SYNC);
        if (fd_ < 0) {
            RCLCPP_FATAL(this->get_logger(), "Failed to open serial port %s", serial_port_.c_str());
            throw std::runtime_error("Serial port open failed");
        }

        configure_serial();

        // === Publisher ===
        imu_pub_ = this->create_publisher<sensor_msgs::msg::Imu>("/imu/data_raw", 1000);

        // === Timer (250 Hz → 4 ms) ===
        timer_ = this->create_wall_timer(1ms, std::bind(&IMUPublisher::publish_imu, this));

        //RCLCPP_INFO(this->get_logger(), "IMU Publisher started on %s at 460800 baud", serial_port_.c_str());
    }

    ~IMUPublisher()
    {
        if (fd_ >= 0) {
            close(fd_);
        }
    }

private:
    //void configure_serial()
    //{
        //struct termios tty;
        //if (tcgetattr(fd_, &tty) != 0) {
            //throw std::runtime_error("Failed to get serial attributes");
        //}

        //cfsetospeed(&tty, baud_rate_);
        //cfsetispeed(&tty, baud_rate_);

        //tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS8; // 8-bit chars
        //tty.c_iflag &= ~IGNBRK;                     // disable break processing
        //tty.c_lflag = 0;                            // no signaling chars, no echo, no canonical
        //tty.c_oflag = 0;                            // no remapping, no delays
        //tty.c_cc[VMIN] = 0;                         // non-blocking read
        //tty.c_cc[VTIME] = 1;                        // 0.1s timeout

        //tty.c_iflag &= ~(IXON | IXOFF | IXANY);     // shut off xon/xoff ctrl

        //tty.c_cflag |= (CLOCAL | CREAD);            // ignore modem controls, enable reading
        //tty.c_cflag &= ~(PARENB | PARODD);          // shut off parity
        //tty.c_cflag &= ~CSTOPB;
        //tty.c_cflag &= ~CRTSCTS;

        //if (tcsetattr(fd_, TCSANOW, &tty) != 0) {
            //throw std::runtime_error("Failed to set serial attributes");
        //}
    //}
    
    void configure_serial()
    {
        struct termios tty;
        if (tcgetattr(fd_, &tty) != 0) {
            throw std::runtime_error("Failed to get serial attributes");
        }

        // Set baud rate (make sure baud_rate_ is a termios constant, e.g. B921600)
        cfsetospeed(&tty, baud_rate_);
        cfsetispeed(&tty, baud_rate_);

        // Raw mode: 8N1, no flow control
        tty.c_cflag &= ~PARENB;
        tty.c_cflag &= ~CSTOPB;
        tty.c_cflag &= ~CSIZE;
        tty.c_cflag |= CS8;
        tty.c_cflag |= (CLOCAL | CREAD);
        tty.c_cflag &= ~CRTSCTS;

        tty.c_iflag &= ~(IXON | IXOFF | IXANY); // no SW flow control
        tty.c_iflag &= ~IGNBRK;

        tty.c_lflag = 0;  // no local modes
        tty.c_oflag = 0;  // no output processing

        // Blocking read until a full packet is ready
        tty.c_cc[VMIN] = 14;   // size of your packet (header + 6x int16)
        tty.c_cc[VTIME] = 1;   // 0.1s timeout

        // Apply attributes
        if (tcsetattr(fd_, TCSANOW, &tty) != 0) {
            throw std::runtime_error("Failed to set serial attributes");
        }

        // Flush away any garbage
        tcflush(fd_, TCIOFLUSH);
    }


    void publish_imu()
    {
        static auto last_data_time = this->get_clock()->now();

        uint8_t header[2];
        uint8_t payload[12];

        bool got_packet = false;

        // Look for header 0xAA 0x55
        while (true) {
            ssize_t n = read(fd_, header, 1);
            if (n <= 0) break; // no data
            if (header[0] == 0xAA) {
                n = read(fd_, header + 1, 1);
                if (n > 0 && header[1] == 0x55) {
                    // Read 12-byte payload
                    n = read(fd_, payload, 12);
                    if (n == 12) {
                        got_packet = true;
                    }
                    break;
                }
            }
        }

        if (!got_packet) {
            // Check timeout
            auto now = this->get_clock()->now();
            if ((now - last_data_time).seconds() > 2.0) {
                RCLCPP_WARN(this->get_logger(), "No IMU data for >2s, resetting serial connection...");
                close(fd_);
                fd_ = open(serial_port_.c_str(), O_RDWR | O_NOCTTY | O_SYNC);
                if (fd_ >= 0) {
                    configure_serial();
                    RCLCPP_INFO(this->get_logger(), "Serial port re-opened");
                } else {
                    RCLCPP_ERROR(this->get_logger(), "Failed to reopen serial port");
                }
                last_data_time = now;
            }
            return;
        }

        // Update last good packet time
        last_data_time = this->get_clock()->now();

        // ===== Unpack payload =====
        auto unpack16 = [](uint8_t *p) -> int16_t {
            return (int16_t)((p[0] << 8) | p[1]);
        };

        int16_t ax = unpack16(&payload[0]);
        int16_t ay = unpack16(&payload[2]);
        int16_t az = unpack16(&payload[4]);
        int16_t gx = unpack16(&payload[6]);
        int16_t gy = unpack16(&payload[8]);
        int16_t gz = unpack16(&payload[10]);

        // Convert to SI
        constexpr double g = 9.81;
        constexpr double accel_scale = g / 16384.0;
        constexpr double deg2rad = M_PI / 180.0;
        constexpr double gyro_scale = deg2rad / 131.0;

        auto imu_msg = sensor_msgs::msg::Imu();
        imu_msg.header.stamp = this->get_clock()->now();
        imu_msg.header.frame_id = "imu_link";

        imu_msg.linear_acceleration.x = ax * accel_scale;
        imu_msg.linear_acceleration.y = ay * accel_scale;
        imu_msg.linear_acceleration.z = az * accel_scale;

        imu_msg.angular_velocity.x = gx * gyro_scale;
        imu_msg.angular_velocity.y = gy * gyro_scale;
        imu_msg.angular_velocity.z = gz * gyro_scale;

        imu_msg.linear_acceleration_covariance[0] = -1.0;
        imu_msg.angular_velocity_covariance[0] = -1.0;

        imu_pub_->publish(imu_msg);
    }


    std::string serial_port_;
    int fd_;
    speed_t baud_rate_;
    rclcpp::Publisher<sensor_msgs::msg::Imu>::SharedPtr imu_pub_;
    rclcpp::TimerBase::SharedPtr timer_;
};


int main(int argc, char * argv[])
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<IMUPublisher>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
