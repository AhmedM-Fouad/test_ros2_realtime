#include <chrono>
#include <memory>
#include <string>
#include <iostream>
#include <vector>
#include <cmath>
#include <stdexcept>
#include <cstring>

#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/float32.hpp>
#include <ackermann_msgs/msg/ackermann_drive_stamped.hpp>

#include <fcntl.h>
#include <unistd.h>
#include <termios.h>

using namespace std::chrono_literals;

class SteeringPublisher : public rclcpp::Node
{
public:
SteeringPublisher()
: Node("steering_publisher")
{
// === Serial Port ===
serial_port_ = "/dev/ttyACM0";
baud_rate_ = B115200;  // match Arduino


    open_serial();

    // === Publisher ===
    steer_pub_ = this->create_publisher<ackermann_msgs::msg::AckermannDriveStamped>(
    "/ackermann_cmd", 10);

    // === Main read loop (1ms) ===
    timer_ = this->create_wall_timer(8ms, std::bind(&SteeringPublisher::publish_steer, this));
}

~SteeringPublisher()
{
    if (fd_ >= 0) {
        close(fd_);
    }
}


private:
void open_serial()
{
if (fd_ >= 0) {
close(fd_);
}


    fd_ = open(serial_port_.c_str(), O_RDWR | O_NOCTTY | O_SYNC);
    if (fd_ < 0) {
        RCLCPP_FATAL(this->get_logger(), "Failed to open serial port %s", serial_port_.c_str());
        throw std::runtime_error("Serial port open failed");
    }

    configure_serial();
    RCLCPP_INFO(this->get_logger(), "Serial port %s opened", serial_port_.c_str());
}

void configure_serial()
{
    struct termios tty;
    if (tcgetattr(fd_, &tty) != 0) {
        throw std::runtime_error("Failed to get serial attributes");
    }

    cfsetospeed(&tty, baud_rate_);
    cfsetispeed(&tty, baud_rate_);

    // Raw mode: 8N1
    tty.c_cflag &= ~PARENB;
    tty.c_cflag &= ~CSTOPB;
    tty.c_cflag &= ~CSIZE;
    tty.c_cflag |= CS8;
    tty.c_cflag |= (CLOCAL | CREAD);
    tty.c_cflag &= ~CRTSCTS;

    tty.c_iflag &= ~(IXON | IXOFF | IXANY);
    tty.c_iflag &= ~IGNBRK;

    tty.c_lflag = 0;
    tty.c_oflag = 0;

    tty.c_cc[VMIN] = 0;
    tty.c_cc[VTIME] = 0;

    if (tcsetattr(fd_, TCSANOW, &tty) != 0) {
        throw std::runtime_error("Failed to set serial attributes");
    }

    tcflush(fd_, TCIOFLUSH);
}

void publish_steer()
{
    static std::vector<uint8_t> buffer;

    uint8_t temp[64];  // read a chunk
    ssize_t n = read(fd_, temp, sizeof(temp));
    if (n > 0) {
        buffer.insert(buffer.end(), temp, temp + n);
    }

    // Parse while buffer has enough data
    while (buffer.size() >= 6) {  // 1 start + 4 float + 1 checksum
        // Look for start byte
        auto it = std::find(buffer.begin(), buffer.end(), 0xAA);
        if (it == buffer.end()) {
            buffer.clear();  // no start found
            return;
        }

        // Remove junk before start
        buffer.erase(buffer.begin(), it);

        // Check if full packet is here
        if (buffer.size() < 6) {
            return;  // wait for more bytes
        }

        // Extract packet
        uint8_t start = buffer[0];
        uint8_t payload[5];
        std::memcpy(payload, &buffer[1], 5);

        // Remove this packet from buffer
        buffer.erase(buffer.begin(), buffer.begin() + 6);

        // Verify checksum
        uint8_t cs = start ^ payload[0] ^ payload[1] ^ payload[2] ^ payload[3];
        if (cs != payload[4]) {
            RCLCPP_WARN(this->get_logger(), "Checksum mismatch");
            continue;
        }

        // Reconstruct float
        float steering;
        std::memcpy(&steering, payload, sizeof(float));

        // RCLCPP_INFO(this->get_logger(), "Steering value: %.2f", steering);

        ackermann_msgs::msg::AckermannDriveStamped msg;

        // Header
        msg.header.stamp = this->now();
        msg.header.frame_id = "odom";  // or "odom", depends on your setup

        // Drive command
        msg.drive.steering_angle = steering;     // from Arduino
        msg.drive.speed = 0.0;                   // placeholder
        msg.drive.steering_angle_velocity = -1.0;
        msg.drive.acceleration = 0.0;
        msg.drive.jerk = 0.0;

        steer_pub_->publish(msg);

    }
}


std::string serial_port_;
int fd_{-1};
speed_t baud_rate_;

rclcpp::Publisher<ackermann_msgs::msg::AckermannDriveStamped>::SharedPtr steer_pub_;

rclcpp::TimerBase::SharedPtr timer_;


};

int main(int argc, char * argv[])
{
rclcpp::init(argc, argv);
auto node = std::make_shared<SteeringPublisher>();
rclcpp::spin(node);
rclcpp::shutdown();
return 0;
}
